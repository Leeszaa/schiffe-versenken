package battleship.factorys.hits;

public interface IHits {

    public boolean isHit();

    public void setHit(boolean isHit);

    
}
