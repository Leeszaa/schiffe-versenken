package battleship.factorys.hits;

public abstract class HitFactory {

    public abstract IHits createHit(boolean isHit);

}
