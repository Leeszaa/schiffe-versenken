/**
 * 
 */
/**
 * @author lisa-
 *
 */
module Battleships {

        requires java.desktop;
}